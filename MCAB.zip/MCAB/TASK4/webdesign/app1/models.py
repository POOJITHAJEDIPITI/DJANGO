from django.db import models

# Create your models here.
class BatchMasterModel(models.Model):
    batchno=models.IntegerField()
    batchid=models.CharField(max_length=50)
    def __str__(self):
        return self.batchid
class CourseMasterModel(models.Model):
    course=models.CharField(max_length=30)
    courseid=models.IntegerField()
    def __str__(self):
        return self.course
