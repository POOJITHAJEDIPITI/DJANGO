from django import forms
from . models import Studentmodel
from . models import Coursemodel
from . models import Enrollmodel

class Studentform(forms.ModelForm):
    class Meta:
        model=Studentmodel
        fields="__all__"
class Courseform(forms.ModelForm):
    class Meta:
        model=Coursemodel
        fields="__all__"
class Enrollform(forms.ModelForm):
    class Meta:
        model=Enrollmodel
        fields="__all__"
