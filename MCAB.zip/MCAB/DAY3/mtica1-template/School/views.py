from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def displayindex(request):
    return HttpResponse('hey this from school app and mtica project')
def index(request):
    return render(request,'index.html')

def displayproject(request):
    return render(request,'project.html')
def displaytask1(request):
    return render(request,'task1.html')
def displaytask2(request):
    return render(request,'task2.html')
def displaytask3(request):
    return render(request,'task3.html')
def displaytask4(request):
    return render(request,'task4.html')
def displaytask5(request):
    return render(request,'task5.html')
def displaytask6(request):
    return render(request,'task6.html')
def displaytask7(request):
    return render(request,'task7.html')
def displaytask8(request):
    return render(request,'task8.html')
def displaytask9(request):
    return render(request,'task9.html')

def displaytask10(request):
    return render(request,'task10.html')





