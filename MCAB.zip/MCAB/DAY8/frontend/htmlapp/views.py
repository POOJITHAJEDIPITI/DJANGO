from django.shortcuts import render
from django.http import HttpResponse
from django.template import *

# Create your views here.
def paragraph(request):
    return render(request,"paragraph.html")
