from django.urls import path
from . import views

urlpatterns=[
    path('paragraph/',views.paragraph,name='paragraph'),
    ]
