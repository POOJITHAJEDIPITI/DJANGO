from django.urls import path
from . import views
urlpatterns=[
    path('poojitha/',views.poojitha,name='poojitha'),
    ]
