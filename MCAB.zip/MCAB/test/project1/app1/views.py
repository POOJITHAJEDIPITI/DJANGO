from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def poojitha(request):
    return HttpResponse('hey this is poojitha from django') 
