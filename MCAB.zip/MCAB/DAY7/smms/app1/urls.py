from django.urls import path
from . import views

urlpatterns=[
    path('balaji/',views.balaji,name='balaji'),
    path('display_BatchMaster/',views.display_BatchMaster,name='display_BatchMaster'),
    path('display_PaperMaster/',views.display_PaperMaster,name='display_PaperMaster'),
     path('display_SemMaster/',views.display_SemMaster,name='display_SemMaster'),
     path('display_CourseMaster/',views.display_CourseMaster,name='display_CourseMaster'),
     path('display_ExamMaster/',views.display_ExamMaster,name='display_ExamMaster'),
     path('display_StudentMaster/',views.display_StudentMaster,name='display_StudentMaster'),
     path('StudentMarks/',views.StudentMarks,name='StudentMarks'),
    path('insert_BatchMaster/',views.insert_BatchMaster,name='insert_BatchMaster'),
     path('insert_Exam/',views.insert_Exam,name='insert_Exam'),
     path('insert_ExamMaster/',views.insert_ExamMaster,name='insert_ExamMaster'),
     path('insert_SemMaster/',views.insert_SemMaster,name='insert_SemMaster'),
     path('insert_PaperMaster/',views.insert_PaperMaster,name='insert_PaperMaster'),
     path('insert_CourseMaster/',views.insert_CourseMaster,name='insert_CourseMaster'),
     path('insert_StudentMaster/',views.insert_StudentMaster,name='insert_StudentMaster'),
     path('insert_Batch/',views.insert_Batch,name='insert_Batch'),
     path('process_batch_entry/',views.process_batch_entry,name='process_batch_entry'),
     path('insert_Paper/',views.insert_Paper,name='insert_Paper'),
     path('process_paper_entry/',views.process_paper_entry,name='process_paper_entry'),
      path('insert_Sem/',views.insert_Sem,name='insert_Sem'),
     path('process_sem_entry/',views.process_sem_entry,name='process_sem_entry'),
      path('insert_Course/',views.insert_Course,name='insert_Course'),
     path('process_course_entry/',views.process_course_entry,name='process_course_entry'),
       path('process_exam_entry/',views.process_exam_entry,name='process_exam_entry'),
       path('image/',views.image,name='image'),
    path('imagelinking/',views.imagelinking,name='imagelinking'),
    path('insert_Student/',views.insert_Student,name='insert_Student'),
     path('insert_Marks/',views.insert_Marks,name='insert_Marks'),
     path('process_student_entry/',views.process_student_entry,name='process_student_entry'),
     path('process_studentmarks_entry/',views.process_studentmarks_entry,name='process_studentmarks_entry'),


    ]
