from django.urls import path
from . import views
urlpatterns=[
    path('paragraph/',views.paragraph,name='paragraph'),
     path('heading/',views.heading,name='heading'),
    path('htmlhomepage/',views.htmlhomepage,name='htmlhomepage'),
     path('marquee/',views.marquee,name='marquee'),
    path('font/',views.font,name='font'),
    ]
