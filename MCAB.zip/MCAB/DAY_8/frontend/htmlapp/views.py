from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def htmlhomepage(request):
    return render(request,"htmlhomepage.html")


def paragraph(request):
    return render(request,"paragraph.html")
def heading(request):
    return render(request,"heading.html")
def marquee(request):
    return render(request,"marquee.html")

def font(request):
    return render(request,"font.html")
