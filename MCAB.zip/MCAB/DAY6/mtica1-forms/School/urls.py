from django.urls import path
from .  import views

urlpatterns=[
     path('imagelinking/',views.imagelinking,name='imagelinking'),
    path('image/',views.image,name='image'),
     path('insert_studentview/',views.insert_studentview,name='insert_studentview'),
      path('process_student_entry/',views.process_student_entry,name='process_student_entry'),
    path('displayindex/',views.displayindex,name='displayindex'),
    path('index/',views.index,name='index'),
    path('displayproject/',views.displayproject,name='displayproject'),
     path('displaytask1/',views.displaytask1,name='displaytask1'),
    path('displaytask2/',views.displaytask2,name='displaytask2'),
    path('displaytask3/',views.displaytask3,name='displaytask3'),
    path('displaytask4/',views.displaytask4,name='displaytask4'),
    path('displaytask5/',views.displaytask5,name='displaytask5'),
    path('displaytask6/',views.displaytask6,name='displaytask6'),
    path('displaytask7/',views.displaytask7,name='displaytask7'),
    path('displaytask8/',views.displaytask8,name='displaytask8'),
    path('displaytask9/',views.displaytask9,name='displaytask9'),
    path('displaytask10/',views.displaytask10,name='displaytask10'),
     path('insert_view/',views.insert_view,name='insert_view'),
     path('display_student/',views.display_student,name='display_student'),
      path('display_course/',views.display_course,name='display_course'),
     path('display_enroll/',views.display_enroll,name='display_enroll'),
      path('insert_studentviewform/',views.insert_studentviewform,name='insert_studentviewform'),
      path('insert_courseviewform/',views.insert_courseviewform,name='insert_courseviewform'),
     path('process_course_entry/',views.process_course_entry,name='process_course_entry'),
        path('insert_enrollviewform/',views.insert_enrollviewform,name='insert_enrollviewform'),
     path('process_enroll_entry/',views.process_enroll_entry,name='process_enroll_entry'),

     

    
    
    ]
