from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from . forms import Studentform
from .models import Studentmodel
from . models import Coursemodel
from . forms import Courseform
from . models import Enrollmodel
from . forms import Enrollform


# Create your views here.
def image(request):
    return render(request,'home.html')
def imagelinking(request):
    return render(request,'home2.html')
def insert_enrollviewform(request):
    context={}
    context['form']=Enrollform()
    return render(request,"enroll_entry.html",context)

def process_enroll_entry(request):
    if request.method =='POST':
       
        jdate_inp=request.POST.get('jdate')

        #create a new patient entry in the database
        ob=Enrollmodel(jdate=jdate_inp)
        ob.save()
        return HttpResponse("data successfully inserted!......")
    else:
        return HttpResponse("invalid request method")


def insert_studentviewform(request):
    context={}
    context['form']=Studentform()
    return render(request,"student_entry.html",context)
def insert_courseviewform(request):
    context={}
    context['form']=Courseform()
    return render(request,"course_entry.html",context)

def insert_studentview(request):
    context={}
    context['form']=Studentform()
    return render(request,"insert_student.html",context)


def process_student_entry(request):
    if request.method =='POST':
        sno_inp=request.POST.get('sno')
        sname_inp=request.POST.get('sname')
        age_inp=request.POST.get('age')

        #create a new patient entry in the database
        ob=Studentmodel(sno=sno_inp,sname=sname_inp,age=age_inp)
        ob.save()
        return HttpResponse("data successfully inserted!......")
    else:
        return HttpResponse("invalid request method")

def process_course_entry(request):
    if request.method =='POST':
        cno_inp=request.POST.get('cno')
        cname_inp=request.POST.get('cname')
       

        #create a new patient entry in the database
        ob=Coursemodel(cno=cno_inp,cname=cname_inp)
        ob.save()
        return HttpResponse("data successfully inserted!......")
    else:
        return HttpResponse("invalid request method")
    
def insert_view(request):
    context={}
    context['form']=Studentform()
    return render(request,"insert_view.html",context)
def display_student(request):
    allstu=Studentmodel.objects.all().values()
    temp=loader.get_template('all_student.html')
    context={
        'data':allstu,
        }
    return HttpResponse(temp.render(context,request))
def display_course(request):
    allcou=Coursemodel.objects.all().values()
    temp=loader.get_template('all_course.html')
    context={
        'data':allcou,
        }
    return HttpResponse(temp.render(context,request))
def display_enroll(request):
    allenro=Enrollmodel.objects.all().values()
    temp=loader.get_template('all_enroll.html')
    context={
        'data':allenro,
        }
    return HttpResponse(temp.render(context,request))




def displayindex(request):
    return HttpResponse('hey this from school app and mtica project')
def index(request):
    return render(request,'index.html')

def displayproject(request):
    return render(request,'project.html')
def displaytask1(request):
    return render(request,'task1.html')
def displaytask2(request):
    return render(request,'task2.html')
def displaytask3(request):
    return render(request,'task3.html')
def displaytask4(request):
    return render(request,'task4.html')
def displaytask5(request):
    return render(request,'task5.html')
def displaytask6(request):
    return render(request,'task6.html')
def displaytask7(request):
    return render(request,'task7.html')
def displaytask8(request):
    return render(request,'task8.html')
def displaytask9(request):
    return render(request,'task9.html')

def displaytask10(request):
    return render(request,'task10.html')





