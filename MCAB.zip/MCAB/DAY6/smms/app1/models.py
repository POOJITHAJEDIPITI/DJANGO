from django.db import models

# Create your models here.
class BatchMaster(models.Model):
    batchNo=models.IntegerField()
    batchId=models.CharField(max_length=50)
    def __str__(self):
        return self.batchId
class PaperMaster(models.Model):
    paperCode=models.CharField(max_length=8)
    paperType=models.CharField(max_length=15)
    papershtName=models.CharField(max_length=50)
    paperName=models.CharField(max_length=40)
    def __str__(self):
        return str(self.paperCode)
class CourseMaster(models.Model):
    course=models.CharField(max_length=4)
    courseId=models.IntegerField(default=3)
    def __str__(self):
        return self.course
class SemMaster(models.Model):
    sem=models.CharField(max_length=4)
    semId=models.IntegerField()

    def __str__(self):
        return self.sem
class ExamMaster(models.Model):
    examId=models.IntegerField()
    examType=models.CharField(max_length=10)
    def __str__(self):
        return self.examType
class StudentMaster(models.Model):
    batchNo=models.ForeignKey(BatchMaster,on_delete=models.CASCADE)
    sem=models.ForeignKey(SemMaster,on_delete=models.CASCADE)
    course=models.ForeignKey(CourseMaster,on_delete=models.CASCADE)
    studregNo=models.IntegerField()
    studName=models.CharField(max_length=25)
    def __str__(self):
        return str(self.studregNo)

class StudentInternalTrans(models.Model):
    course=models.ForeignKey(CourseMaster,on_delete=models.CASCADE)
    batch=models.ForeignKey(BatchMaster,on_delete=models.CASCADE)
    sem=models.ForeignKey(SemMaster,on_delete=models.CASCADE)
    examType=models.ForeignKey(ExamMaster,on_delete=models.CASCADE)
    regNo=models.IntegerField()
    nameofthestudent=models.CharField(max_length=50)
    paperCode=models.ForeignKey(PaperMaster,on_delete=models.CASCADE)
    #paperName=models.CharField(max_length=40)
    marks=models.IntegerField(default=3)

    def __str__(self):
        return self.nameofthestudent
