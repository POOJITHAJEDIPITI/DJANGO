from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def displayindex(request):
    return HttpResponse('hey this from school app and mtica project')
