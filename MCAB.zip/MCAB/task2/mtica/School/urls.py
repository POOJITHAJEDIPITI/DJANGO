from django.urls import path
from .  import views

urlpatterns=[
    path('displayindex/',views.displayindex,name='displayindex'),
    ]
