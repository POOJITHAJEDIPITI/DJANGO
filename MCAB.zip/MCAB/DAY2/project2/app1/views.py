from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def balaji(request):
    temp='I am class representative for MCA B section'
    return HttpResponse(temp)

def nagendra(request):
    return HttpResponse('I am nagendra from MCA B')

def displayBlue(request):
    return render(request, "blue.html")
def displayindex(request):
    return render(request, "index.html")
