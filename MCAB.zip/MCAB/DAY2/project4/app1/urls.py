from django.urls import path
from . import views
urlpatterns=[
    path('balaji/',views.balaji,name='balaji'),
    path('nagendra/',views.nagendra,name='nagendra'),
path('displayBlue/',views.displayBlue,name='displayBlue'),
  path('displayindex/',views.displayindex,name='displayindex'),
    path('co/',views.co,name='co'), 
    ]
