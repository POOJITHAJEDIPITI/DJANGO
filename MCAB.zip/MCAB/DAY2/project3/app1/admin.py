from django.contrib import admin
from . models import School
from . models import Product
# Register your models here.
admin.site.register(School)
admin.site.register(Product)
