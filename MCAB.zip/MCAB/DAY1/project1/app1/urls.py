from django.urls import path
from . import views

urlpatterns=[
    path('balaji/',views.balaji,name='balaji'),
    path('nagendra/',views.nagendra,name='nagendra'),
    ]
