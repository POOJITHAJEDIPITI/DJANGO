
from django.urls import path
from . import views

urlpatterns = [
    path('edit/<int:book_id>/', views.edit_book, name='edit_book'),
    path('book/<int:book_id>/', views.book_detail, name='book_detail'),
    # other paths as needed
]
