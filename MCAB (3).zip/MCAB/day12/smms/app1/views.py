from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.template import loader


from .models import BatchMaster
from .models import PaperMaster
from .models import CourseMaster
from .models import SemMaster
from .models import StudentMaster
from .models import ExamMaster
from .models import StudentInternalTrans
from . forms import BatchMasterForm
from . forms import CourseMasterForm
from . forms import ExamMasterForm
from . forms import SemMasterForm
from . forms import PaperMasterForm
from . forms import StudentMasterForm
from . forms import StudentInternalTransForm
# Create your views here.
def image(request):
    return render(request,"home.html")
def imagelinking(request):
    return render(request,"home2.html")
def insert_Batch(request):
    return render(request,"batch_entry.html")
def process_batch_entry(request):
    if request.method=='POST':
        batchId_inp=request.POST.get('batchId')
        batchNo_inp=request.POST.get('batchNo')
        ob=BatchMaster(batchNo=batchNo_inp,batchId=batchId_inp)
        ob.save()
        return render(request,"home3.html")
    else:
        return HttpResponse("invalid request method")

def insert_Paper(request):
    return render(request,"paper_entry.html")
def process_paper_entry(request):
    if request.method=='POST':
        papercode_inp=request.POST.get('paperCode')
        papertype_inp=request.POST.get('paperType')
        papershtname_inp=request.POST.get('papershtName')
        papername_inp=request.POST.get('paperName')
        ob=PaperMaster(paperCode=papercode_inp,paperType=papertype_inp,papershtName=papershtname_inp,paperName=papername_inp)
        ob.save()
        return render(request,"home3.html")
    else:
        return HttpResponse("invalid request method")

def insert_Sem(request):
    return render(request,"sem_entry.html")
def process_sem_entry(request):
    if request.method=='POST':
        sem_inp=request.POST.get('sem')
        semid_inp=request.POST.get('semId')
       
        ob=SemMaster(sem=sem_inp,semId=semid_inp)
        ob.save()
        return render(request,"home3.html")
    else:
        return HttpResponse("invalid request method")

def insert_Course(request):
    return render(request,"course_entry.html")
def process_course_entry(request):
    if request.method=='POST':
        course_inp=request.POST.get('course')
        courseid_inp=request.POST.get('courseId')
       
        ob=CourseMaster(course=course_inp,courseId=courseid_inp)
        ob.save()
        return render(request,"home4.html")
    else:
        return HttpResponse("invalid request method")
def insert_Exam(request):
    return render(request,"exam_entry.html")
def process_exam_entry(request):
    if request.method=='POST':
        examid_inp=request.POST.get('examId')
        examtype_inp=request.POST.get('examType')
        ob=ExamMaster(examId=examid_inp,examType=examtype_inp)
        ob.save()
        return render(request,"home3.html")
    else:
      

       return HttpResponse("invalid request method")
def insert_Student(request):
    return render(request,"student_entry.html")
def process_student_entry(request):
    if request.method=='POST':
        batchno_inp=request.POST.get('batchNo')
        sem_inp=request.POST.get('sem')
        course_inp=request.POST.get('course')
        studregno_inp=request.POST.get('studregNo')
        studname_inp=request.POST.get('studName')
        ob=StudentMaster(batchNo=batchno_inp,sem=sem_inp,course=course_inp,studregNo=studregno_inp,studName=studname_inp)
        ob.save()
        return render(request,"home3.html")
    else:
        return HttpResponse("invalid request method")

        
def add2studentmarks(request):
    return render(request,"marks_entry.html")
def process_studentmarks_entry(request):
    if request.method=='POST':
        course_inp=request.POST.get('course')
        sem_inp=request.POST.get('sem')
        examtype_inp=request.POST.get('examType')
        studregno_inp=request.POST.get('studregNo')
        studname_inp=request.POST.get('nameofthestudent')
        papercode_inp=request.POST.get('paperCode')
        ob=StudentInternalTrans(course=course_inp,sem=sem_inp,examType=examtype_inp,studregNo=studregno_inp,nameofthestudent=studname_inp,paperCode=papercode_inp)
        ob.save()
        return render(request,"home3.html")
    else:
        return HttpResponse("invalid request method")







def insert_BatchMaster(request):
    context={}
    context['form']=BatchMasterForm()
    return render(request,"insert_batch.html",context)
def insert_CourseMaster(request):
    context={}
    context['form']=CourseMasterForm()
    return render(request,"insert_course.html",context)
def insert_ExamMaster(request):
    context={}
    context['form']=ExamMasterForm()
    return render(request,"insert_exam.html",context)
def insert_SemMaster(request):
    context={}
    context['form']=SemMasterForm()
    return render(request,"insert_sem.html",context)
def insert_PaperMaster(request):
    context={}
    context['form']=PaperMasterForm()
    return render(request,"insert_paper.html",context)
def insert_StudentMarks(request):
    context={}
    context['form']=StudentInternalTransForm()
    return render(request,"insert_marks.html",context)
def insert_StudentMaster(request):
    context={}
    context['form']=StudentMasterForm()
    return render(request,"insert_student.html",context)
def add1studentmarks(request):
    context={}
    context['form']=StudentInternalTransForm()
    return render(request,"insert_marks.html",context)
def balaji(request):
    return HttpResponse('hi')
def display_BatchMaster(request):
    all_batch=BatchMaster.objects.all().values()
    temp=loader.get_template('all_batch.html')
    context={
        'data':all_batch,
        }
    return HttpResponse(temp.render(context,request))

def display_PaperMaster(request):
    all_paper=PaperMaster.objects.all().values()
    temp=loader.get_template('all_paper.html')
    context={
        'data':all_paper,
        }
    return HttpResponse(temp.render(context,request))

def display_CourseMaster(request):
    all_course=CourseMaster.objects.all().values()
    temp=loader.get_template('all_course.html')
    context={
        'data':all_course,
        }
    return HttpResponse(temp.render(context,request))

def display_SemMaster(request):
    all_sem=SemMaster.objects.all().values()
    temp=loader.get_template('all_sem.html')
    context={
        'data':all_sem,
        }
    return HttpResponse(temp.render(context,request))

def display_ExamMaster(request):
    all_exam=ExamMaster.objects.all().values()
    temp=loader.get_template('all_exam.html')
    context={
        'data':all_exam,
        }
    return HttpResponse(temp.render(context,request))
def display_StudentMaster(request):
    all_stu=StudentMaster.objects.all().values()
    temp=loader.get_template('all_student.html')
    context={
        'data':all_stu,
        }
    return HttpResponse(temp.render(context,request))
def displaystudentmarks(request):
    all_stu1=StudentInternalTrans.objects.all().values()
    temp=loader.get_template('all_internal.html')
    context={
        'data':all_stu1,
        }
    return HttpResponse(temp.render(context,request))










