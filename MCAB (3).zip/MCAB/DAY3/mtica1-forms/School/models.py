from django.db import models

# Create your models here.
class Studentmodel(models.Model):
    sno=models.IntegerField()
    sname=models.CharField(max_length=20)
    age=models.IntegerField(default=18)

    def __str__(self):
        return self.sname

class Coursemodel(models.Model):
    cno=models.IntegerField()
    cname=models.CharField(max_length=20)

    def __str__(self):
        return self.cname
class Enrollmodel(models.Model):
   # jdate=models.DateTimeField(auto_now_add=True)
    cno=models.ForeignKey(Coursemodel,on_delete=models.CASCADE)
    sno=models.ForeignKey(Studentmodel,on_delete=models.CASCADE)
    jdate=models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return str(self.sno)+'_'+str(self.cno)


    
