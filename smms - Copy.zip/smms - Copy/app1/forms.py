from django  import forms
from . models import BatchMaster
from . models import CourseMaster
from . models import SemMaster
from . models import ExamMaster
from . models import StudentMaster
from . models import StudentInternalTrans
from . models import PaperMaster
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User



class SearchForm(forms.Form):
    query = forms.CharField(label='Search', max_length=100)

class SignupForm(UserCreationForm):
    class Meta:
        model=User
        fields=['username','password1','password2']

class LoginForm(forms.Form):
    username=forms.CharField()
    password=forms.CharField(widget=forms.PasswordInput)

class BatchMasterForm(forms.ModelForm):
    class Meta:
        model=BatchMaster
        fields="__all__"

#validating batchmasterform
def clean(self):
    super(BatchMasterForm, self).clean()
    batchNo=self.cleaned_data.get('batchNo')
    batchId=self.cleaned_data.get('batchId')

    if batchNo<0:
        self._errors['batchNo']=self.error_class(['batch no should be positive numbers'])
    if len(batchId)<7:
         self._errors['batchId']=self.error_class(['batch id should contain 7 characters'])
    return self.cleaned_data
        

class CourseMasterForm(forms.ModelForm):
    class Meta:
        model=CourseMaster
        fields="__all__"
class SemMasterForm(forms.ModelForm):
    class Meta:
        model=SemMaster
        fields="__all__"
class ExamMasterForm(forms.ModelForm):
    class Meta:
        model=ExamMaster
        fields="__all__"
class StudentMasterForm(forms.ModelForm):
    class Meta:
        model=StudentMaster
        fields="__all__"
class StudentInternalTransForm(forms.ModelForm):
    class Meta:
        model=StudentInternalTrans
        fields="__all__"
class PaperMasterForm(forms.ModelForm):
    class Meta:
        model=PaperMaster
        fields="__all__"
